import java.util.ArrayList;

public class Member extends User {
    private ArrayList<Book> borrowedBooks = new ArrayList<>();

    public Member(int id, String name, String email, String password) {
        super(id, name, email, password);
    }

    public void borrowBook(Book book) {
        borrowedBooks.add(book);
    }

    public void returnBook(Book book) {
        borrowedBooks.remove(book);
    }

    public void printBorrowedBooks() {
        System.out.print("BorrowedBooks{books=");
        if (borrowedBooks.isEmpty()) {
            System.out.println("}");
        } else {
            for (Book book : borrowedBooks) {
                System.out.println(book + "}"); break;
            }
        }
    }
}